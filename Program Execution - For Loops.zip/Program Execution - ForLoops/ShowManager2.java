import java.util.LinkedList;

/** A show class
 * @author jcpatel and ajain5
 */
class ShowManager2 {

    ShowManager2() {
    }

    /**
     * Finds the shows that aren't special and have a broadcast time within a certain starttime
     * @param shows a list of Shows
     * @return returns a ShowSummary with a new list of shows after cleaning.
     */
    public ShowSummary organizeShows(LinkedList<Show> shows) {
        LinkedList<Show> daytimeShows = new LinkedList<>();
        LinkedList<Show> primetimeShows = new LinkedList<>();
        LinkedList<Show> latenightShows = new LinkedList<>();
        ShowSummary holder = new ShowSummary(daytimeShows, primetimeShows, latenightShows);
        LinkedList<Show> hold = new LinkedList<Show>();

        for (Show s : shows) {
            if ((!s.isSpecial) && (s.broadcastTime < 100 || s.broadcastTime >= 600)) {
                hold.add(s);
            }

        }
        for (Show s : hold) {
            if ( s.broadcastTime < 100 || s.broadcastTime >= 2200) {
                latenightShows.add(s);
            } else if (s.broadcastTime < 2200 && s.broadcastTime >= 1700) {
                primetimeShows.add(s);
            } else if (s.broadcastTime < 1700 && s.broadcastTime >= 600) {
                daytimeShows.add(s);
            }
        }
        return holder;

    }


}
