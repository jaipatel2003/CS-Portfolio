import java.util.LinkedList;

/** An earthquake class
 * @author jcpatel and ajain5
 */
class Earthquake1 {
    Earthquake1() {
    }

    // checks whether a datum is a date
    boolean isDate(double anum) {
        return (int) anum > 10000000;
    }

    // extracts the month from an 8-digit date
    int extractMonth(double dateNum) {
        return ((int) dateNum % 10000) / 100;
    }

    /**
     * Finds the max frequency of months of a reading
     *
     * @param data  A list of earthquake data readings
     * @param month a given month
     * @return Date of highest frequencies along with frequency
     */
    public LinkedList<MaxHzReport> dailyMaxForMonth(LinkedList<Double> data, int month) {
        LinkedList<MaxHzReport> maxhz = new LinkedList<MaxHzReport>();
        LinkedList<Earthquake1> quake = new LinkedList<Earthquake1>();
        double date = 0;
        double max = 0;
        for (int i = 0; i < data.size(); i++) {
            if (isDate(data.get(i))) {
                date = data.get(i);
                max = 0;
            } else if (data.get(i) > max)
                max = data.get(i);

            if (extractMonth(date) == month) {
                if (data.size() == i + 1)
                    maxhz.add(new MaxHzReport(date, max));
                else{
                    if (isDate(data.get(i+1))){
                        maxhz.add(new MaxHzReport(date, max));
                    }
                }
            }
        }
        return maxhz;
    }
}