import static org.junit.Assert.*;
import org.junit.Test;
import java.util.LinkedList;

public class EarthquakeExamples {
    Earthquake1 E1 = new Earthquake1();
    LinkedList<Double> noData = new LinkedList<Double>();
    LinkedList<Double> threeDates = new LinkedList<Double>();
    LinkedList<MaxHzReport> NovReports = new LinkedList<MaxHzReport>();

    public EarthquakeExamples() {
        threeDates.add(20151013.0);
        threeDates.add(10.0);
        threeDates.add(5.0);
        threeDates.add(20151020.0);
        threeDates.add(40.0);
        threeDates.add(50.0);
        threeDates.add(45.0);
        threeDates.add(20151101.0);
        threeDates.add(6.0);
        NovReports.add(new MaxHzReport(20151101.0,6.0));
    }

    @Test
    public void instructorTestEQ() {
        assertEquals(NovReports,
                E1.dailyMaxForMonth(threeDates, 11));
    }

    @Test
    public void testearthquakefcn(){

    }

    @Test
    public void testearthquakefcn2(){

    }

    @Test
    public void testearthquakefcn3(){

    }

}

/*
Problem 2 Version 1 Subtasks
- Search through list of data
- Use isDate function to find data that are dates
- Use extractMonth function to store month value of the dates
- Check to see if date is greater than the tempMax
- Identify tempMax as the new max
- Add new report with stored date and stored max
Problem 2 Version 2 Subtasks

Problem 2 Version 2 Subtasks
- Search through list of data
- Clean and only keep positive data values
- Store positive data values in a holder
- Search through holder
- Use isDate function to find data that are dates
- Use extractMonth function to store month value of the dates
- Check to see if date is greater than the tempMax
- Identify tempMax as the new max
- Add new report with stored date and stored max

 */