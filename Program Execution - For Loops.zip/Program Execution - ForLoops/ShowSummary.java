import java.util.LinkedList;

class ShowSummary {

    LinkedList<Show> daytime;
    LinkedList<Show> primetime;
    LinkedList<Show> latenight;

    ShowSummary() {
        this.daytime = new LinkedList<Show>();
        this.primetime = new LinkedList<Show>();
        this.latenight = new LinkedList<Show>();
    }

    ShowSummary(LinkedList<Show> daytime, LinkedList<Show> primetime, LinkedList<Show> latenight) {
        this.daytime = daytime;
        this.primetime = primetime;
        this.latenight = latenight;
    }

    public boolean equals(Object obj) {
        ShowSummary otherShowSummary = (ShowSummary) obj;//use with caution
        if (daytime.size() == (otherShowSummary.daytime.size()) &&
                primetime.size() == (otherShowSummary.primetime.size()) &&
                latenight.size() == (otherShowSummary.latenight.size())) {

            for (int i = 0; i < daytime.size(); i++) {
                if (!otherShowSummary.daytime.get(i).title.equals(daytime.get(i).title) &&
                        otherShowSummary.daytime.get(i).broadcastTime != (daytime.get(i).broadcastTime)){
                    return false;
                }
            }
            for (int j = 0; j < primetime.size(); j++) {
                if (!otherShowSummary.primetime.get(j).title.equals(primetime.get(j).title) &&
                        otherShowSummary.primetime.get(j).broadcastTime != (primetime.get(j).broadcastTime)){
                    return false;
                }
            }
            for (int k = 0; k < latenight.size(); k++) {
                if (!otherShowSummary.latenight.get(k).title.equals(latenight.get(k).title) &&
                        otherShowSummary.latenight.get(k).broadcastTime != (latenight.get(k).broadcastTime))
                {
                    return false;
                }
            }
            return true;
            }
            return false;
        }

}
