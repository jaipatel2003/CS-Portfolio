import java.util.LinkedList;

public class TodaysWeatherReport {
    GregorianCalendar todaysdate;
    LinkedList<Double> tempreadings;
    LinkedList<Double> rainfallreadings;

    public TodaysWeatherReport(GregorianCalendar todaysdate, LinkedList<Double> tempreadings, LinkedList<Double> rainfallreadings){
        this.todaysdate = todaysdate;
        this.tempreadings = tempreadings;
        this.rainfallreadings = rainfallreadings;
    }


}
