public class Reading {
    Time time;
    double temp;
    double rainfall;

    public Reading(Time time, double temp, double rainfall){
        this.time = time;
        this.temp = temp;
        this.rainfall = rainfall;
    }


}
