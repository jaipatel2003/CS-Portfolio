import java.util.LinkedList;

public class WeatherStation {
    TodaysWeatherReport WeatherReport;

    public WeatherStation(){

    }

    public double averageMonthTemp(int month, int year) {
        double tempReadingsSum;
        double tempreadingsAverage;
        GregorianCalendar todaysDate= (year, month, i);
        //int month = this.WeatherReport.GregorianCalendar(year, month,i);
        for (double)
            for (double aDouble : this.WeatherReport.tempreadings) {
                tempReadingsSum = aDouble + tempReadingsSum;
            }
        tempreadingsAverage = tempReadingsSum / this.WeatherReport.tempreadings.size();

    }




    public double totalMonthRainfall(int month, int year){
        return 0;
    }

    public void addTodaysReport(GregorianCalendar date, LinkedList<Reading> readings){

    }

}
